package ch.hslu.oop.sw08.elements;

public class Lead extends Element{
    protected Lead() {
        super("Pb", 1744, -327);
    }
}
