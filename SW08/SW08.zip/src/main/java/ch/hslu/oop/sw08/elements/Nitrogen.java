package ch.hslu.oop.sw08.elements;

public class Nitrogen extends Element {
    protected Nitrogen() {
        super("N", -196, -210);
    }
}
